using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.SceneManagement;

public class LevelUnlock : MonoBehaviour
{
    public void LevelUNlock(int index)
    {
        PlayerPrefs.SetInt("LevelUnlock", index);
        SceneManager.LoadScene(0);
    }
    public void AllLevelUnlock()
    {
        SceneManager.LoadScene(0);
    }
}
