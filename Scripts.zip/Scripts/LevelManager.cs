using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor.UI;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    public GameObject[] LevelBtns;
    // Start is called before the first frame update
    private void Awake()
    {
        if (PlayerPrefs.GetInt("LevelUnlock") == 0)
        {
            PlayerPrefs.SetInt("LevelUnlock", 1);
        }
    }
    void Start()
    {
        for (int i = 0; i < LevelBtns.Length; i++)
        {
            LevelBtns[i].GetComponent<Button>().interactable = false;
        }
        for(int i=1;i<= PlayerPrefs.GetInt("LevelUnlock"); i++)
        {
            LevelBtns[i-1].GetComponent<Button>().interactable = true;
        }
    }
    public void loadscene(int index)
    {
        SceneManager.LoadScene(index);
    }
   
}
